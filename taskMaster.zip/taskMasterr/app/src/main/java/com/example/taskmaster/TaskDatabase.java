package com.example.taskmaster;

import androidx.room.Database;
import androidx.room.RoomDatabase;

    @Database(entities = {Tasks.class}, version = 2)
    public abstract class TaskDatabase extends RoomDatabase {
        public abstract TaskDao taskDao();
}

